from pathlib import Path
import csv
import hashlib
import json

root = Path(__file__).resolve().parents[1]
expected = json.loads((root / "table_checksums.json").read_text(encoding="utf-8"))
for name, target in expected.items():
    with (root / "translated" / name).open(encoding="utf-8-sig", newline="") as f:
        rows = list(csv.reader(f))
    canonical = json.dumps(rows, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    if hashlib.sha256(canonical).hexdigest() != target:
        raise SystemExit("Table differs from the reference: " + name)
    print(f"Verified {name}: {len(rows)-1} data rows")
