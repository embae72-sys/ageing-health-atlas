"""Translate the two aggregate KLoSA RQ1 CSVs using Python's standard library.

Usage: python3 localize_tables.py ANALYSIS_DIR OUTPUT_DIR
"""
import argparse
import csv
from pathlib import Path
import re
import shutil

RESULT_HEADERS = {
    '연도':'year', '영역':'domain', '지표ID':'indicator_id', '지표':'indicator',
    '구분':'stratification', '집단':'group', '분모 정의':'denominator_definition',
    '대상자 수':'eligible_n', '유효 응답 수':'valid_n', '결측 수':'missing_n',
    '해당자 수':'event_n', '가중 유효 분모':'weighted_valid_denominator',
    '단위':'unit', '가중 추정값':'weighted_estimate', '가중 1사분위':'weighted_q1',
    '가중 중앙값':'weighted_median', '가중 3사분위':'weighted_q3', '자료 상태':'data_status',
}
CROSSWALK_HEADERS = {
    '지표ID':'indicator_id', '영역':'domain', '지표':'indicator', '단위':'unit', '분모':'denominator_definition',
    'KLoSA 2018 (7차)':'klosa_2018_wave7', 'KLoSA 2024 (10차)':'klosa_2024_wave10',
    'CHARLS 2018 (4차) 원문항·조화변수':'charls_2018_wave4_items_or_harmonized_variables',
    '한국 산식·코딩':'klosa_derivation', '비교 용도':'comparison_status',
    '중국 적용 시 확인':'charls_comparability_notes', '한국 출처':'klosa_source_url',
    '중국 설문':'charls_questionnaire_url',
}
TEXT = {
    '장애·기능제한':'Disability and functional limitations', '만성질환 부담':'Chronic disease burden',
    '인지기능':'Cognitive function', '장기요양 필요·수발':'Long-term care needs and receipt of care',
    '전체':'Overall', '성별':'Sex', '연령':'Age', '학력':'Educational attainment',
    '장애판정 경험':'History of physician-assessed disability', '진단질환 수':'Number of diagnosed conditions',
    '65세 이상':'65 years and older', '65–74세':'65–74 years', '75–84세':'75–84 years', '85세 이상':'85 years and older',
    '남성':'Men', '여성':'Women', '초졸 이하':'Primary school or less', '중졸':'Middle school',
    '고졸':'High school', '대졸 이상':'College or higher', '판정 경험 없음':'No history of physician-assessed disability',
    '판정 경험 있음':'History of physician-assessed disability', '0개':'0 conditions', '1개':'1 condition',
    '2개':'2 conditions', '3개 이상':'3 or more conditions',
    '해당 연도 65세 이상':'Respondents aged 65 or older in the survey year',
    '검사 중 도움을 받지 않은 65세 이상':'Respondents aged 65 or older who received no assistance during the test',
    '공통 8항목 중 1개 이상 도움 필요':'Respondents needing assistance with at least one of the eight common activities',
    '%':'%', '개':'conditions', '점':'points', '산출':'Estimated', '현 배포본 미제공':'Unavailable in the current release',
    '우선 비교':'Priority for comparison', '조건부':'Conditional on harmonization',
    '우선 비교·IADL 조건부':'Priority for comparison, with conditions for IADLs',
    '진단 이력 비교':'Comparison of diagnosis histories', '한국 보완':'Supplementary Korean measure',
    '인지 하위영역 후보':'Candidate cognitive subdomain', '탐색적':'Exploratory',
    '한국 제도 맥락':'Korean policy context',
}
LABELS = {
    '의사에게 장애판정을 받은 경험':'Ever assessed by a physician as having a disability',
    '건강 때문에 일에 지장이 있음':'Health limits ability to work',
    '원거리 시력이 나쁜 편 또는 매우 나쁨':'Poor or very poor distance vision',
    '근거리 시력이 나쁜 편 또는 매우 나쁨':'Poor or very poor near vision',
    '청력이 나쁜 편 또는 매우 나쁨':'Poor or very poor hearing',
    '옷 입기에 도움 필요':'Needs assistance with dressing', '목욕·샤워에 도움 필요':'Needs assistance with bathing or showering',
    '차려진 음식 먹기에 도움 필요':'Needs assistance with eating a prepared meal','화장실 이용에 도움 필요':'Needs assistance with using the toilet',
    '식사 준비에 도움 필요':'Needs assistance with preparing meals','장보기·물건 구매에 도움 필요':'Needs assistance with shopping',
    '금전관리에 도움 필요':'Needs assistance with managing money','약 복용 관리에 도움 필요':'Needs assistance with taking medications',
    '기본 일상생활 4항목 중 도움 필요':'Needs assistance with at least one of four basic activities of daily living',
    '고혈압 진단 경험':'Ever diagnosed with hypertension','당뇨병·고혈당 진단 경험':'Ever diagnosed with diabetes or high blood sugar',
    '암·악성종양 진단 경험':'Ever diagnosed with cancer or a malignant tumour','만성 폐질환 진단 경험':'Ever diagnosed with chronic lung disease',
    '간질환 진단 경험':'Ever diagnosed with liver disease','심장질환 진단 경험':'Ever diagnosed with heart disease',
    '뇌혈관질환 진단 경험':'Ever diagnosed with cerebrovascular disease','관절염·류마티스 진단 경험':'Ever diagnosed with arthritis or rheumatism',
    '진단받은 질환 수':'Number of diagnosed conditions','복합만성질환 2개 이상':'Multimorbidity (two or more diagnosed conditions)',
    '만성질환 3개 이상':'Three or more diagnosed chronic conditions','치매 진단 경험':'Ever diagnosed with dementia',
    '경도인지장애 진단 경험':'Ever diagnosed with mild cognitive impairment','K-MMSE-2 총점':'K-MMSE-2 total score',
    '시간지남력 4항목':'Orientation to time (four items)','계절 포함 시간지남력':'Orientation to time including season',
    '연속 뺄셈':'Serial sevens','세 단어 즉시등록':'Immediate registration of three words','세 단어 지연회상':'Delayed recall of three words',
    '검사 중 도움을 전혀 받지 않은 응답자의 총점':'K-MMSE-2 total score among respondents who completed the test without assistance',
    '도구적 일상생활 4항목 중 도움 필요':'Needs assistance with at least one of four instrumental activities of daily living',
    '공통 8항목 중 도움 필요':'Needs assistance with at least one of the eight common activities',
    '기본 4항목 독립·도구적 활동에서만 도움 필요':'Independent in all four basic activities but needs help with at least one instrumental activity',
    '공통 8항목 중 2개 이상 도움 필요':'Needs assistance with at least two of the eight common activities',
    '한국 전체 17항목 중 도움 필요':'Needs assistance with at least one of all 17 Korean survey activities',
    '공통 8항목 필요자 중 수발자 없음':'Has no caregiver, among respondents needing help with the eight common activities',
    '공통 8항목 필요자 중 의사 장애판정 경험 없음':'No history of physician-assessed disability, among respondents needing help with the eight common activities',
    '장기요양보험 서비스 현재 이용':'Currently uses Korean Long-Term Care Insurance services',
    '공통 8항목 필요자 중 장기요양보험 서비스 현재 이용':'Currently uses Korean Long-Term Care Insurance services, among respondents needing help with the eight common activities',
}
RULES = {
    '개인별로 첫 참여부터 해당 차수까지 의사 장애판정 예(1)를 누적. 이전 예가 없고 현 차수 아니오(5)이면 0, 이외 미상':
        "Link each respondent's reports from first participation through the index wave. Code 1 for any affirmative report of a physician's disability assessment. Code 0 if there is no prior affirmative report and the current answer is no (5). Treat all other cases as unknown.",
    '1·2 = 지장 있음':'Codes 1 and 2 indicate that health limits work.',
    '4·5를 포함하고 맹인(C074=3)을 포함':'Count ratings of 4 or 5 and include blindness (C074=3).',
    '4·5를 포함. 평소 보청기 사용자는 착용 상태':'Count ratings of 4 or 5. Respondents who usually wear hearing aids report aided hearing.',
    '1 = 독립, 3·5 = 도움 필요':'1 = independent, 3 or 5 = needs assistance.',
    '생성변수 1 = 진단, 5 = 없음':'Derived variable: 1 = diagnosed, 5 = no reported diagnosis.',
    '생성변수 1 = 진단, 5 = 없음, 3 = 확진 집계 제외':'Derived variable: 1 = diagnosed, 5 = no reported diagnosis. Code 3 is a valid response and does not count as a confirmed case.',
    '지정한 8개 질환 모두 유효한 사람의 진단 수 (0–8)':'Count diagnoses (0–8) among respondents with valid information on all eight specified conditions.',
    '지정한 8개 질환 모두 유효한 사람의 진단 수가 2개 이상':'At least two diagnoses among respondents with valid information on all eight conditions.',
    '지정한 8개 질환 모두 유효한 사람의 진단 수가 3개 이상':'At least three diagnoses among respondents with valid information on all eight conditions.',
    '질환 이력 생성변수 코드 1. 코드 3은 진단문항 Cadd_01과 대조':'Code 1 in the derived disease-history variable. The meaning of code 3 was cross-checked against diagnostic item Cadd_01.',
    '질환 이력 생성변수 코드 3. 코드 3은 진단문항 Cadd_01과 대조':'Code 3 in the derived disease-history variable, cross-checked against diagnostic item Cadd_01.',
    '기관 제공 총점 0–30':'Provider-released total score, range 0–30.',
    '연·월·일 정답 수 + 요일 정답 (0–4)':'Sum correct responses for year, month, date and day of the week (0–4).',
    '연·월·일 + 요일 + 계절 (0–5)':'Sum correct responses for year, month, date, day of the week and season (0–5).',
    '각 시행의 정답 합계 (0–5)':'Sum correct responses across the five subtractions (0–5).',
    '첫 제시에서 등록한 단어 수 (0–3)':'Count words correctly registered on first presentation (0–3).',
    '지연 후 회상한 단어 수 (0–3)':'Count words recalled after a delay (0–3).',
    'C420=1인 응답자의 0–30점 총점':'Total score (0–30) among respondents with C420=1.',
    '기본 4항목 도움 0개, 도구적 4항목 도움 1개 이상. 공통 8개 모두 유효':'Needs help with none of the four basic activities and at least one of the four instrumental activities. Require valid responses on all eight.',
    '전체 수발자 5칸을 검토. 1번 칸 56이고 어느 칸에도 유효 수발자가 없으면 해당':'Check all five caregiver slots. Classify as no caregiver when slot one is 56 and no slot contains a valid caregiver.',
    '공통 8항목 필요자 중 어느 차수에도 판정 경험이 없고 현재 문항에도 아니오로 응답':'Among those needing help with at least one common activity, count those with no positive disability assessment at any wave and a current answer of no.',
    '이용 응답 우선. 인지 또는 신청이 아니오여서 건너뛴 경우 비이용으로 코딩':'Use the reported service-use response first. Code non-use when a negative answer on awareness or application caused the service-use item to be skipped.',
}
for suffix, threshold in [('1개 이상','one or more'),('2개 이상','two or more'),('17개 중 1개 이상','one or more of all 17')]:
    RULES['전 항목 유효(1·3·5). 부분(3)·전적(5) 도움을 합산. '+suffix] = (
        'Require a valid response (1, 3 or 5) for every item. Count activities requiring partial (3) or full (5) assistance. '
        f'Threshold: {threshold}.')
CHARLS_NOTES = {
    '한국은 의사 판정 경험, 중국은 스스로 보고한 유형별 장애. 현재 장애등록 여부와도 구분':
        'KLoSA captures a history of physician-assessed disability. CHARLS asks whether respondents have each type of disability. Current administrative registration is a separate measure.',
    '중국은 일할 수 없음·장시간 불가·문제없음으로 구분. 한국은 지장의 정도를 물음':
        'CHARLS distinguishes inability to work, inability to work long hours and no problem working. KLoSA asks about the degree of interference with work.',
    '중국 4는 보통, 5는 나쁨. 5를 우선 대응하고 응답범주 전체로 민감도 확인':
        'CHARLS code 4 means fair and code 5 means poor. Use 5 as the initial match and assess sensitivity across all response categories.',
    '중국 4는 보통, 5는 나쁨. 5를 우선 대응하고 응답범주 전체로 민감도 확인. 중국 DA032=2 실명도 포함':
        'CHARLS code 4 means fair and code 5 means poor. Use 5 as the initial match and assess sensitivity across all response categories. Include blindness (DA032=2).',
    '8개 신체질환에 한정. 진단 접근성·문항 범위에 영향. 질환별 결과 병기':
        'Covers eight physical conditions. Access to diagnosis and the scope of each item affect the count. Report condition-specific estimates alongside it.',
    '중국은 기억 관련 질환·파킨슨병 등을 함께 질문. 동등한 진단율로 비교하기 어려움':
        "The Chinese item covers several conditions, including memory-related conditions and Parkinson's disease. The resulting diagnosis rates have different case definitions.",
    '검사판·언어·채점·조사연도가 다름':'The test version, language, scoring and survey years differ.',
    '4개 날짜 단위가 일치. 중국 미실시 및 무응답 제외':'The four date components align. Exclude nonadministration and nonresponse in CHARLS.',
    '중국 조화변수 r4orient는 4점. r4ssn을 더해 만점 5점':'The harmonized CHARLS variable r4orient has a maximum of 4. Add r4ssn for a maximum of 5.',
    '직전 응답 기준으로 채점. 거부·미실시, 검사 보조·채점 지침 확인':
        'Score each subtraction relative to the immediately preceding response. Check refusals, nonadministration, assistance and scoring instructions.',
    '중국 3단어 과제 첫 시행의 정답 수. 10단어 조화변수와 다름. 사용 언어·자극어 차이':
        'Use the number correct on the first trial of the CHARLS three-word task. The harmonized ten-word measure is a different task. The language and stimulus words differ.',
    '중국 3단어 과제 사용. 반복 제시 횟수와 회상 지연·중간 과제가 다름':
        'Use the CHARLS three-word task. The number of presentations, recall interval and intervening tasks differ.',
    '검사 보조 여부에 따라 표본이 달라지는 민감도 분석':
        'A sensitivity analysis restricting the sample by whether assistance was received during the test.',
    '공통 8항목 내부 분류. 도구적 활동의 성역할과 수행 기회를 고려':
        'Classification within the eight common activities. Consider gender roles and opportunities to perform instrumental activities.',
    '도움이 필요한 활동 수. 소요시간·등급과 별도':
        'Counts activities requiring help. Care hours and formal care-need grades are separate measures.',
    '조사별 전체 문항 수와 구성이 다름':'The number and mix of activities in the full instruments differ between surveys.',
    '중국은 전체 조사 활동 중 도움 수령 0·1을 확인. 특수결측을 0으로 간주하지 않음. 양국 수발 문항이 포괄하는 활동의 수와 범위가 다름':
        'Check the CHARLS 0/1 indicator of help received across all surveyed activities. Preserve special missing codes. The caregiver modules cover different numbers and types of activities.',
    '의사 판정·행정상 장애등록·장기요양 인정은 각각 다른 개념':
        'Physician assessment, administrative disability registration and certification for long-term care are distinct measures.',
    '이용에 대한 자기보고. 보험 인정률 또는 전체 필요 충족률과 구분':
        'Self-reported use of services. Insurance eligibility and the proportion of all care needs met require separate measures.',
}
item_start = '중국 원문항 3·4를 도움 필요, 1·2를 독립 수행으로 분류. 선행 이동문항에 의한 정규 생략은 코드북 절차 적용. 응답 누락은 결측'
item_en = ('Code CHARLS responses 3 and 4 as needing assistance and 1 and 2 as independent. '
           'Apply the codebook procedure for valid skips triggered by the preceding mobility items. Treat item nonresponse as missing.')
CHARLS_NOTES[item_start] = item_en
for ko,en in {
    '옷을 꺼내고 여미는 과정 포함':'Dressing includes getting clothes out and fastening them.',
    '한국은 혼자 등을 못 미는 경우 제외':'In KLoSA, an inability to scrub one’s back unaided on its own is excluded.',
    '도구를 쓰더라도 혼자 수행하면 도움 없음':'Unaided eating is classified as independent even when an implement is used.',
    '한국은 옷 벗기·뒤처리, 중국은 앉고 일어서기 명시':'KLoSA specifies removing clothing and cleaning oneself. CHARLS specifies sitting down and standing up.',
    '재료·요리·상차림. 중국은 건강 원인을 명시하여 역할 분담 주의':'Includes preparing ingredients, cooking and serving. CHARLS specifies health-related reasons. Consider household role allocation.',
    '한국은 일반 물건 구매, 중국은 식료품 구매':'KLoSA includes general shopping. CHARLS asks about buying groceries.',
    '양국 모두 지출·재산 관리 포함. 한국은 큰돈 관리 위임도 부분 도움':'Both cover spending and managing assets. KLoSA counts delegating large financial transactions as partial help.',
    '정해진 시간·용량. 비복용·해당 없음과 무응답 구분 필요':'Covers the timing and dose of medicines. Distinguish no medicine use or inapplicability from nonresponse.',
    '역할 분담·장보기 범위·금전 위임 확인':'Check household roles, the scope of shopping and delegation of money management.',
    '장기요양 필요의 기능상 대리지표':'Functional proxy for long-term care need.',
}.items():
    CHARLS_NOTES[item_start+'. '+ko] = item_en+' '+en
for ko,en in {
    '혈압 실측과 구분':'Based on diagnosis history. Measured blood pressure is a separate outcome.',
    '양국 모두 고혈당 진단을 포함':'Both surveys include a diagnosis of high blood sugar.',
    '경미한 피부암 제외':'Exclude minor skin cancers.',
    '암 제외. 양국 질환 예시와 천식 처리 확인':'Exclude cancer. Check disease examples and how each survey treats asthma.',
    '한국 지방간 제외. 중국 지방간·종양·암 제외':'KLoSA excludes fatty liver. CHARLS excludes fatty liver, tumours and cancer.',
    '양국 심장질환 예시와 범위가 다를 수 있음':'The examples and types of heart disease covered may differ.',
    '한국 코드 3은 의증·일과성 허혈발작으로 확진 개수에서 제외. 중국은 뇌졸중':
        'KLoSA code 3 denotes suspected stroke or transient ischaemic attack and does not count as a confirmed diagnosis. CHARLS asks about stroke.',
    '진단 경험에 따른 응답':'Based on a self-reported diagnosis history.',
}.items():
    CHARLS_NOTES[ko+' • 중국은 이전 차수 진단이 반영된 0·1 변수 사용'] = en+' Use the CHARLS binary variable incorporating diagnoses from prior waves.'

VARIABLE_PHRASES = {
    '현 배포본 미제공':'Unavailable in the current release',
    '매 차수 동일인 연결':'same respondent linked across waves',
    '자기보고 장애유형':'self-reported disability types', '광범위':'broader definition',
    '직접 대응 보류':'Direct mapping deferred',
    '이용 가능한 도움·대리응답 표지 확인':'Check available flags for assistance and proxy interviews',
    '직접 대응 없음':'No direct counterpart',
    '등 활동별 도움 수령':'and other activity-specific help-receipt items',
    '중국 자기보고 장애와 기능제한의 중첩은 별도 분석':'assess the overlap of self-reported disability and functional limitations separately in CHARLS',
    '한국 제도 문항. 동일 급여 대응 미확정':'Korean programme-specific item. An equivalent benefit has yet to be established.',
}
NUMERIC_OR_ID = {'연도','지표ID','대상자 수','유효 응답 수','결측 수','해당자 수','가중 유효 분모','가중 추정값','가중 1사분위','가중 중앙값','가중 3사분위','한국 출처','중국 설문'}
VARIABLES = {'KLoSA 2018 (7차)', 'KLoSA 2024 (10차)', 'CHARLS 2018 (4차) 원문항·조화변수'}
def translate(header, value):
    if header in NUMERIC_OR_ID:
        return value
    if header in VARIABLES:
        for ko,en in VARIABLE_PHRASES.items():
            value = value.replace(ko,en)
        return value
    specific = {'지표':LABELS, '한국 산식·코딩':RULES, '중국 적용 시 확인':CHARLS_NOTES}
    return specific.get(header,TEXT)[value]

def prepare(source_dir, destination):
    destination.mkdir(parents=True, exist_ok=True)
    for basename,slug,headers in [('한국_가중결과.csv','results',RESULT_HEADERS),('한중_변수대응표.csv','crosswalk',CROSSWALK_HEADERS)]:
        original = source_dir / basename
        with original.open(encoding='utf-8-sig',newline='') as handle:
            reader = csv.DictReader(handle)
            assert reader.fieldnames == list(headers), f'Updated schema for {basename}'
            rows = list(reader)
        english = []
        for row in rows:
            translated = {headers[k]:translate(k,v) for k,v in row.items()}
            assert not any(re.search('[가-힣]', v) for v in translated.values()), translated
            english.append(translated)
        assert len(rows) == len(english)
        for kr,en in zip(rows,english):
            assert all(kr[k] == en[headers[k]] for k in headers.keys() & NUMERIC_OR_ID)
        shutil.copyfile(original, destination / f'{slug}-ko.csv')
        with (destination / f'{slug}-en.csv').open('w',encoding='utf-8-sig',newline='') as handle:
            writer = csv.DictWriter(handle, fieldnames=headers.values())
            writer.writeheader()
            writer.writerows(english)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('analysis_dir',type=Path)
    parser.add_argument('output_dir',type=Path)
    args = parser.parse_args()
    prepare(args.analysis_dir, args.output_dir)
