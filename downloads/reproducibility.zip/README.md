# KLoSA research question 1 · Research reproduction materials

## English

This package reproduces the Korean cross-sectional estimates and the variable crosswalk for adults aged 65 or older in 2018 and 2024. The Chinese column identifies candidate items in CHARLS 2018 from the survey documentation. This calculation uses respondent data from Korea only.

### Required inputs

1. Extract this ZIP to an empty folder. The analysis reads paths relative to this folder. The package supplies the analysis script, the two aggregate tables it uses and the English table translation.
2. Obtain KLoSA structure-converted data from the Korea Employment Information Service. Use the same release as the original analysis. Keep the unmodified SAS archive at `KLoSA/SAS.zip`. It must contain `str07_20260413.sas7bdat` and `str10_20260413.sas7bdat`.
3. From the corresponding Excel distribution, put the ten `str` workbooks directly in `KLoSA/EXCEL/`. Waves 1–7, 9 and 10 use the suffix `_20260413.xlsx`. Wave 8 uses `str08_20260827.xlsx`. The analysis uses the ten waves to reconstruct the history of a physician's disability assessment. Use one workbook per wave.
4. Use Python 3 with pandas and NumPy. The verified environment used Python 3.12.14, pandas 2.2.3 and NumPy 2.3.5. In a fresh virtual environment with Python 3.12, install the two packages with `python -m pip install pandas==2.2.3 numpy==2.3.5`.

### Run

From the extracted package folder, run these commands in order.

```sh
python analysis/rq1_health_ltc_20261123/analyze.py
python tools/localize_tables.py analysis/rq1_health_ltc_20261123 translated
python tools/verify_tables.py
```

The first command compares selected source fields between the SAS and Excel releases, checks internal consistency and writes two Korean-language CSV files next to the analysis script. The second command preserves the Korean tables and writes English versions to `translated/`. The third checks all four files against the published downloads using CSV cell values. Verification includes the full reported numeric precision and all missing cells.

The weighted estimates use each wave's integrated individual cross-sectional weight. The results table lists the unweighted numbers eligible, observed and missing for each indicator and the weighted denominator among valid respondents. Binary outcomes also have an unweighted event count. Score and count indicators have weighted quartiles. For 2018 cognitive test measures absent from the release, the status field records their unavailability. A blank is distinct from a recorded zero.

### Sources

- Korea Employment Information Service. KLoSA data releases and cognitive data notice. https://survey.keis.or.kr/klosa/klosadownload/List.jsp
- Korea Employment Information Service. Data collection and English survey overview. https://survey.keis.or.kr/eng/klosa/klosa01.jsp
- Peking University. CHARLS 2018 questionnaires and codebooks. https://charls.pku.edu.cn/en/Data/a2018_CHARLS_Wave_4.htm
- Gateway to Global Aging Data. Harmonized CHARLS Version D.2 creation documentation. https://g2aging.org/harmonized-charls/creation-code

## 한국어

이 묶음은 KLoSA 2018년과 2024년 각 조사 시점의 65세 이상 한국 응답자에 대한 가중 추정값과 한중 변수 대응표를 재현한다. 중국 열에는 CHARLS 2018년 설문 및 조화변수 문서에서 확인한 비교 후보 문항을 담았다.

### 원자료 준비

1. 빈 폴더에 이 ZIP 파일을 푼다. 원래 분석 스크립트와 검증에 쓰는 이전 집계표 두 개, 영문 표 변환기가 함께 들어 있다.
2. 한국고용정보원에서 원분석과 같은 배포판의 구조변환 SAS·Excel 자료를 확보한다. SAS 압축파일을 `KLoSA/SAS.zip`에 둔다. 내부에 `str07_20260413.sas7bdat`와 `str10_20260413.sas7bdat`가 있어야 한다.
3. 구조변환 Excel 파일을 차수마다 하나씩 `KLoSA/EXCEL/`에 둔다. 1~7차와 9~10차 파일명 끝은 `_20260413.xlsx`, 8차는 `str08_20260827.xlsx`다. 1~10차 자료는 의사의 장애판정 이력을 연결하는 데 사용한다.
4. Python 3.12 환경에 pandas 2.2.3과 NumPy 2.3.5를 설치한다. 위 영문 안내에 검증 환경과 설치 명령이 있다.

### 실행과 검증

압축을 푼 폴더에서 위의 명령 세 개를 차례로 실행한다. 첫 명령은 SAS와 Excel에서 사용 항목을 서로 대조한 뒤 분석 스크립트 옆에 한국어 결과표와 한중 변수 대응표를 만든다. 두 번째는 `translated/` 폴더에 국문·영문 CSV 4개를 만들고, 세 번째는 이 네 파일의 셀 값이 사이트에 실린 다운로드 파일과 일치하는지 확인한다.

추정값에는 차수별 개인 통합 횡단가중치를 적용했다. 각 행에 비가중 대상자 수·유효 응답 수·결측 수와 가중 유효 분모가 있다. 비율 지표에는 비가중 해당자 수를, 점수·진단 수 지표에는 가중 사분위수를 담았다. 2018년 인지검사 점수는 현 배포본에 제공되지 않아 자료 상태를 별도로 표시했다. 빈칸과 실제 응답값 0을 구분한다. 자료별 출처 링크는 위 Sources에 수록했다.
