"""KLoSA RQ1. Run with Python 3, pandas and numpy, from any directory.
Only aggregate outputs are written. Each source worksheet is checked against SAS.
"""
from pathlib import Path
import io
import re
import zipfile
import xml.etree.ElementTree as ET

import numpy as np
import pandas as pd

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
K_URL = 'https://survey.keis.or.kr/klosa/klosaque/index.jsp'
CN_URL = 'https://charls.charlsdata.com/Public/ashelf/public/uploads/document/2018-charls-wave4/application/CHARLS_2018_Household_Questionnaire.pdf'
CARE = pd.read_csv(ROOT/'analysis/klosa_common_care_20261012/tables/06_common_definitions.csv')
CORE = CARE.loc[CARE.selected_core].copy()
DISEASES = [
    ('a','고혈압',1,'hibpe','혈압 실측과 구분'),
    ('b','당뇨병·고혈당',3,'diabe','양국 모두 고혈당 진단을 포함'),
    ('c','암·악성종양',4,'cancre','경미한 피부암 제외'),
    ('d','만성 폐질환',5,'lunge','암 제외. 양국 질환 예시와 천식 처리 확인'),
    ('e','간질환',6,'livere','한국 지방간 제외. 중국 지방간·종양·암 제외'),
    ('f','심장질환',7,'hearte','양국 심장질환 예시와 범위가 다를 수 있음'),
    ('g','뇌혈관질환',8,'stroke','한국 코드 3은 의증·일과성 허혈발작으로 확진 개수에서 제외. 중국은 뇌졸중'),
    ('i','관절염·류마티스',13,'arthre','진단 경험에 따른 응답')
]
DIS, CHR, COG, LTC = '장애·기능제한','만성질환 부담','인지기능','장기요양 필요·수발'
BASE = '해당 연도 65세 이상'
metadata = {}
records = []
scores_2024 = ['mmse','orientation4','orientation5','serial','immediate','recall','unassisted']
all_helpers = set(range(2,17)) | set(range(27,41)) | {47,48,49,50,52,53,54,55}

def read_original_excel(path, columns):
    """Read selected columns from original worksheets whose style headers vary by wave."""
    ns = {'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
    with zipfile.ZipFile(path) as z:
        strings = [''.join(t.text or '' for t in e.findall('.//s:t',ns)) for e in ET.fromstring(z.read('xl/sharedStrings.xml'))]
        xml = z.read('xl/worksheets/sheet1.xml')
    rows = re.finditer(rb'<row\b[^>]*>.*?</row>',xml,re.DOTALL)
    first = ET.fromstring(next(rows).group())
    wanted = {}
    for cell in first:
        val = cell.findtext('v')
        if val is None:
            continue
        name = strings[int(val)] if cell.get('t')=='s' else val
        if name in columns:
            wanted[re.match(r'[A-Z]+',cell.get('r'))[0]] = name
    assert set(wanted.values()) == set(columns), set(columns)-set(wanted.values())
    pattern = re.compile(rb'<c r="(' + b'|'.join(k.encode() for k in wanted) + rb')\d+"([^>]*)>\s*<v>([^<]+)</v>')
    def row_values(row):
        values = {}
        for col, attributes, value in pattern.findall(row):
            item = strings[int(value)] if b't="s"' in attributes else value
            try:
                values[wanted[col.decode()]] = float(item)
            except (ValueError, TypeError):
                values[wanted[col.decode()]] = np.nan
        return values
    return pd.DataFrame((row_values(r.group()) for r in rows),columns=columns).dropna(how='all').set_index('pid').sort_index()

def verify_excel(path, sas, columns):
    excel = read_original_excel(path, columns)
    other = sas[columns].set_index('pid').sort_index()
    assert excel.index.equals(other.index)
    for c in other:
        assert np.allclose(excel[c],other[c],rtol=0,atol=1e-7,equal_nan=True), c

def binary(s, yes, valid):
    return s.isin(yes).astype(float).where(s.isin(valid))

def at_least(s, n):
    return s.ge(n).astype(float).where(s.notna())

def weighted_quantiles(y, w):
    order = np.argsort(y)
    weights = np.cumsum(w[order])
    return y[order][np.searchsorted(weights, weights[-1]*np.array([.25,.50,.75]))]

def disability_history():
    snapshots, positive = {}, set()
    for path in sorted((ROOT/'KLoSA/EXCEL').glob('str??_*.xlsx')):
        wave = path.name[3:5]
        column = 'w'+wave+'C003'
        data = read_original_excel(path,['pid',column])
        assert data.index.is_unique and not data.index.hasnans
        yes, no = [set(data.index[data[column].eq(v)]) for v in [1,5]]
        assert positive.isdisjoint(no)
        positive.update(yes)
        if wave in ('07','10'):
            snapshots[wave] = positive.copy()
    return snapshots

def analyze(year, wave, disability, subgroup_data=None):
    with zipfile.ZipFile(ROOT/'KLoSA/SAS.zip') as z:
        file = z.read(f'str{wave}_20260413.sas7bdat')
    d = pd.read_sas(io.BytesIO(file),format='sas7bdat',encoding='cp949')
    pre = 'w'+wave
    selected = ['A002_age','gender1','edu','wgt_ac','C003','C005','C074','C076','C077','C083',
                'chronic_m','C318n','C319n','C320n']
    selected += ['chronic_'+i[0] for i in DISEASES] + [f'C{i}' for i in range(201,218)]
    selected += [f'C218_{i:02}' for i in range(1,6)]
    if year==2024:
        selected += ['mmse']+[f'C{i}' for i in range(401,421)]
    else:
        assert pre+'mmse' not in d and pre+'C401' not in d
    if subgroup_data is not None:
        selected += ['hhinc','hhsize']
    cols = [pre+s for s in selected]
    assert d.pid.is_unique and d.pid.notna().all()
    verify_excel(ROOT/f'KLoSA/EXCEL/str{wave}_20260413.xlsx',d,['pid']+cols)
    a = d[cols].copy()
    a.columns = selected
    a = a.loc[a.A002_age.ge(65)]
    assert len(a)=={2018:4352,2024:4504}[year] and a.wgt_ac.gt(0).all()
    w = a.wgt_ac
    if subgroup_data is not None:
        subgroup_data['all_ages'] = d.set_index('pid')[pre+'A002_age']
        subgroup_data['profile'] = a[['A002_age','gender1','edu','wgt_ac','hhinc','hhsize']].assign(pid=d.loc[a.index,'pid'])
        subgroup_data['indicators'] = {}
    everyone = pd.Series(True,index=a.index)
    groups = [('전체','65세 이상',everyone)]
    groups += [('연령',name,a.A002_age.between(lo,hi)) for name,lo,hi in [('65–74세',65,74),('75–84세',75,84),('85세 이상',85,150)]]
    groups += [('성별',name,a.gender1.eq(v)) for name,v in [('남성',1),('여성',5)]]
    groups += [('학력',name,a.edu.eq(v)) for v,name in enumerate(['초졸 이하','중졸','고졸','대졸 이상'],1)]
    def add(key, area, name, values, kvars, cnvars, method, grade, note, unit='%', base=BASE, eligible=None, extra=False):
        variables = ' '.join(kvars.split())
        metadata[key] = {'지표ID':key,'영역':area,'지표':name,'단위':unit,'분모':base,
            'KLoSA 2018 (7차)':', '.join('w07'+v for v in variables.split()) if key not in scores_2024 else '현 배포본 미제공',
            'KLoSA 2024 (10차)':', '.join('w10'+v for v in variables.split()),
            'CHARLS 2018 (4차) 원문항·조화변수':cnvars,'한국 산식·코딩':method,'비교 용도':grade,'중국 적용 시 확인':note,
            '한국 출처':K_URL,'중국 설문':CN_URL}
        if eligible is None: eligible = everyone
        if subgroup_data is not None:
            subgroup_data['indicators'][key] = (values.where(eligible), eligible)
        for kind, label, subset in groups:
            if kind=='학력' and area!=COG: continue
            if kind in ('진단질환 수','장애판정 경험') and not extra: continue
            base_mask = eligible & subset
            mask = base_mask & values.notna()
            n = int(mask.sum())
            y, wt = values[mask].to_numpy(float), w[mask].to_numpy(float)
            estimate = np.average(y,weights=wt) if n else np.nan
            is_pct = unit=='%'
            if is_pct and n: assert np.isin(y,[0,1]).all()
            quantiles = weighted_quantiles(y,wt) if n and not is_pct else [np.nan]*3
            records.append({'연도':year,'영역':area,'지표ID':key,'지표':name,'구분':kind,'집단':label,'분모 정의':base,
                         '대상자 수':int(base_mask.sum()),'유효 응답 수':n,'결측 수':int(base_mask.sum())-n,
                         '해당자 수':int(y.sum()) if n and is_pct else np.nan,
                         '가중 유효 분모':wt.sum() if n else np.nan,'단위':unit,'가중 추정값':estimate*(100 if is_pct else 1),
                         '가중 1사분위':quantiles[0],'가중 중앙값':quantiles[1],'가중 3사분위':quantiles[2],
                         '자료 상태':'현 배포본 미제공' if year==2018 and key in scores_2024 else ('산출' if n else '유효 응답 없음')})
    ever_yes = d.loc[a.index,'pid'].isin(disability)
    ever_dx = ever_yes.astype(float).where(ever_yes | a.C003.eq(5))
    assert ever_dx.notna().all()
    add('adjud',DIS,'의사에게 장애판정을 받은 경험',ever_dx,'C003','DA005[1–5], DA006_W4 (자기보고 장애유형)',
        '개인별로 첫 참여부터 해당 차수까지 의사 장애판정 예(1)를 누적. 이전 예가 없고 현 차수 아니오(5)이면 0, 이외 미상',
        '한국 보완','한국은 의사 판정 경험, 중국은 스스로 보고한 유형별 장애. 현재 장애등록 여부와도 구분')
    groups += [('장애판정 경험',label,ever_dx.eq(v)) for v,label in [(0,'판정 경험 없음'),(1,'판정 경험 있음')]]
    add('work',DIS,'건강 때문에 일에 지장이 있음',binary(a.C005,[1,2],[1,2,3,4]),'C005','DB036_W4','1·2 = 지장 있음','조건부',
        '중국은 일할 수 없음·장시간 불가·문제없음으로 구분. 한국은 지장의 정도를 물음')
    for k,cn,label in [('C076','DA033','원거리 시력'),('C077','DA034','근거리 시력'),('C083','DA039','청력')]:
        vision = k!='C083'
        poor = binary(a[k],[4,5],[1,2,3,4,5])
        if vision: poor = poor.mask(a.C074.eq(3),1.0)
        add(k,DIS,label+'이 나쁜 편 또는 매우 나쁨',poor,'C074 '+k if vision else k,'DA032 + '+cn if vision else cn,
            '4·5를 포함'+('하고 맹인(C074=3)을 포함' if vision else '. 평소 보청기 사용자는 착용 상태'),'조건부',
            '중국 4는 보통, 5는 나쁨. 5를 우선 대응하고 응답범주 전체로 민감도 확인'+('. 중국 DA032=2 실명도 포함' if vision else ''))
    all_items = pd.DataFrame({i:binary(a[f'C{i}'],[3,5],[1,3,5]) for i in range(201,218)})
    core_ids = CORE.klosa_2024.str[4:].astype(int).tolist()
    ids_adl,ids_iadl = core_ids[:4],core_ids[4:]
    def itemcount(ids): return all_items[ids].sum(axis=1,min_count=len(ids))
    adl,iadl,total,full = [itemcount(ids) for ids in (ids_adl,ids_iadl,core_ids,list(range(201,218)))]
    k_adl, k_iadl = [' '.join('C'+str(i) for i in ids) for ids in (ids_adl,ids_iadl)]
    k_core = k_adl+' '+k_iadl
    cn_adl,cn_iadl = [' '.join(CORE.loc[CORE.domain.eq(domain),'charls_2018_harmonized']) for domain in ('ADL','IADL')]
    cn_core = cn_adl+' / '+cn_iadl
    need_rule = '전 항목 유효(1·3·5). 부분(3)·전적(5) 도움을 합산'
    flags = '중국 원문항 3·4를 도움 필요, 1·2를 독립 수행으로 분류. 선행 이동문항에 의한 정규 생략은 코드북 절차 적용. 응답 누락은 결측'
    for row in CORE.itertuples():
        i = int(row.klosa_2024[4:])
        add(f'item{i}',DIS if row.domain=='ADL' else LTC,row.activity+'에 도움 필요',all_items[i],f'C{i}',
            row.charls_question+' / '+row.charls_2018_harmonized,'1 = 독립, 3·5 = 도움 필요', '우선 비교' if row.domain=='ADL' else '조건부',flags+'. '+row.caution)
    add('adl4',DIS,'기본 일상생활 4항목 중 도움 필요',at_least(adl,1),k_adl,cn_adl,need_rule+'. 1개 이상','우선 비교',flags)
    dx = {}
    for suffix,label,num,cn,note in DISEASES:
        k = 'chronic_'+suffix
        dx[k] = binary(a[k],[1],[1,3,5] if suffix=='g' else [1,5])
        add(k,CHR,label+' 진단 경험',dx[k],k,f'DA007_{num}_ / r4{cn}',
            '생성변수 1 = 진단, 5 = 없음'+(', 3 = 확진 집계 제외' if suffix=='g' else ''),'진단 이력 비교',note+' • 중국은 이전 차수 진단이 반영된 0·1 변수 사용')
    dx_n = pd.DataFrame(dx).sum(axis=1,min_count=8)
    k_dx = ' '.join(dx.keys())
    cn_dx = ', '.join('r4'+v[3] for v in DISEASES)
    for key,label,n in [('burden','진단받은 질환 수',None),('multi','복합만성질환 2개 이상',2),('three','만성질환 3개 이상',3)]:
        add(key,CHR,label,dx_n if n is None else at_least(dx_n,n),k_dx,cn_dx,
            '지정한 8개 질환 모두 유효한 사람의 진단 수'+(f'가 {n}개 이상' if n else ' (0–8)'),
            '우선 비교','8개 신체질환에 한정. 진단 접근성·문항 범위에 영향. 질환별 결과 병기','개' if n is None else '%')
    groups += [('진단질환 수',label,mask) for label,mask in [('0개',dx_n.eq(0)),('1개',dx_n.eq(1)),('2개',dx_n.eq(2)),('3개 이상',dx_n.ge(3))]]
    for key,code,label in [('dementia',1,'치매 진단 경험'),('mci',3,'경도인지장애 진단 경험')]:
        add(key,COG,label,binary(a.chronic_m,[code],[1,3,5]),'chronic_m','DA007_12_ / r4mmryprke (광범위)',
            f'질환 이력 생성변수 코드 {code}. 코드 3은 진단문항 Cadd_01과 대조','한국 보완','중국은 기억 관련 질환·파킨슨병 등을 함께 질문. 동등한 진단율로 비교하기 어려움')
    cogvars = {'mmse':('K-MMSE-2 총점','mmse','직접 대응 보류','기관 제공 총점 0–30','한국 보완','검사판·언어·채점·조사연도가 다름'),
               'orientation4':('시간지남력 4항목','C402 C403','r4orient / DC001·003·005·006_W4','연·월·일 정답 수 + 요일 정답 (0–4)','인지 하위영역 후보','4개 날짜 단위가 일치. 중국 미실시 및 무응답 제외'),
               'orientation5':('계절 포함 시간지남력','C402 C403 C404','r4orient + r4ssn / DC001·002·003·005·006_W4','연·월·일 + 요일 + 계절 (0–5)','인지 하위영역 후보','중국 조화변수 r4orient는 4점. r4ssn을 더해 만점 5점'),
               'serial':('연속 뺄셈','C408 C409 C410 C411 C412','r4ser7 / DC014_W4_1–5','각 시행의 정답 합계 (0–5)','인지 하위영역 후보','직전 응답 기준으로 채점. 거부·미실시, 검사 보조·채점 지침 확인'),
               'immediate':('세 단어 즉시등록','C401','DC013_W4_1','첫 제시에서 등록한 단어 수 (0–3)','탐색적','중국 3단어 과제 첫 시행의 정답 수. 10단어 조화변수와 다름. 사용 언어·자극어 차이'),
               'recall':('세 단어 지연회상','C407','DC015_W4','지연 후 회상한 단어 수 (0–3)','탐색적','중국 3단어 과제 사용. 반복 제시 횟수와 회상 지연·중간 과제가 다름'),
               'unassisted':('검사 중 도움을 전혀 받지 않은 응답자의 총점','mmse C420','이용 가능한 도움·대리응답 표지 확인','C420=1인 응답자의 0–30점 총점','한국 보완','검사 보조 여부에 따라 표본이 달라지는 민감도 분석')}
    nan = pd.Series(np.nan,index=a.index)
    sc = {k:nan for k in cogvars}
    if year==2024:
        sub = {}
        for i in range(401,420):
            maxval = {401:3,402:3,405:4,407:3,416:3}.get(i,1)
            s = a[f'C{i}']
            sub[i] = s.where(s.isin([*range(1,maxval+1),5])).replace(5,0)
        def sub_sum(*ids): return pd.concat([sub[i] for i in ids],axis=1).sum(axis=1,min_count=len(ids))
        sc.update(mmse=a.mmse.where(a.mmse.between(0,30)),immediate=sub[401],recall=sub[407],
                  orientation4=sub_sum(402,403),orientation5=sub_sum(402,403,404),serial=sub_sum(*range(408,413)))
        sc['unassisted'] = sc['mmse'].where(a.C420.eq(1))
        assert np.allclose(sc['mmse'],sub_sum(*range(401,420)),equal_nan=True)
    for key,(label,kv,cv,rule,grade,note) in cogvars.items():
        restricted = key=='unassisted'
        add(key,COG,label,sc[key],kv,cv,rule,grade,note,'점',
            '검사 중 도움을 받지 않은 65세 이상' if restricted else BASE,
            a.C420.eq(1) if restricted and year==2024 else (everyone & False if restricted else everyone))
    add('iadl4',LTC,'도구적 일상생활 4항목 중 도움 필요',at_least(iadl,1),k_iadl,cn_iadl,need_rule+'. 1개 이상','조건부',flags+'. 역할 분담·장보기 범위·금전 위임 확인')
    add('need8',LTC,'공통 8항목 중 도움 필요',at_least(total,1),k_core,cn_core,need_rule+'. 1개 이상','우선 비교·IADL 조건부',flags+'. 장기요양 필요의 기능상 대리지표',extra=True)
    only_iadl = (adl.eq(0)&iadl.ge(1)).astype(float).where(total.notna())
    add('iadlonly',LTC,'기본 4항목 독립·도구적 활동에서만 도움 필요',only_iadl,k_core,cn_core,
        '기본 4항목 도움 0개, 도구적 4항목 도움 1개 이상. 공통 8개 모두 유효','우선 비교·IADL 조건부','공통 8항목 내부 분류. 도구적 활동의 성역할과 수행 기회를 고려')
    add('need2',LTC,'공통 8항목 중 2개 이상 도움 필요',at_least(total,2),k_core,cn_core,need_rule+'. 2개 이상','조건부','도움이 필요한 활동 수. 소요시간·등급과 별도')
    add('full17',LTC,'한국 전체 17항목 중 도움 필요',at_least(full,1),' '.join(f'C{i}' for i in range(201,218)),'직접 대응 없음',
        need_rule+'. 17개 중 1개 이상','한국 보완','조사별 전체 문항 수와 구성이 다름')
    roster_vars = [f'C218_{i:02}' for i in range(1,6)]
    roster = a[roster_vars]
    has = roster.isin(all_helpers).any(axis=1)
    none = roster.iloc[:,0].eq(56) & ~has
    known = (has|none) & full.ge(1)
    assert not (full.ge(1)&~known).any()
    add('nohelper',LTC,'공통 8항목 필요자 중 수발자 없음',none.astype(float).where(known),k_core+' '+' '.join(roster_vars),
        'r4rcany / DB010_W2 등 활동별 도움 수령 + DB022_W3_1',
        '전체 수발자 5칸을 검토. 1번 칸 56이고 어느 칸에도 유효 수발자가 없으면 해당','조건부',
        '중국은 전체 조사 활동 중 도움 수령 0·1을 확인. 특수결측을 0으로 간주하지 않음. 양국 수발 문항이 포괄하는 활동의 수와 범위가 다름',
        base='공통 8항목 중 1개 이상 도움 필요',eligible=total.ge(1))
    add('noadjud',LTC,'공통 8항목 필요자 중 의사 장애판정 경험 없음',1-ever_dx,k_core+' C003',
        'DA005[1–5] / 중국 자기보고 장애와 기능제한의 중첩은 별도 분석',
        '공통 8항목 필요자 중 어느 차수에도 판정 경험이 없고 현재 문항에도 아니오로 응답',
        '한국 보완','의사 판정·행정상 장애등록·장기요양 인정은 각각 다른 개념',
        base='공통 8항목 중 1개 이상 도움 필요',eligible=total.ge(1))
    use = binary(a.C320n,[1],[1,5])
    use = use.mask(use.isna() & (a.C318n.eq(5) | a.C319n.eq(5)),0.)
    for key,label,elig,base in [('insurance','장기요양보험 서비스 현재 이용',everyone,BASE),
                                ('coverage','공통 8항목 필요자 중 장기요양보험 서비스 현재 이용',total.ge(1),'공통 8항목 중 1개 이상 도움 필요')]:
        add(key,LTC,label,use,('' if key=='insurance' else k_core+' ')+'C318n C319n C320n','한국 제도 문항. 동일 급여 대응 미확정',
            '이용 응답 우선. 인지 또는 신청이 아니오여서 건너뛴 경우 비이용으로 코딩','한국 제도 맥락','이용에 대한 자기보고. 보험 인정률 또는 전체 필요 충족률과 구분',base=base,eligible=elig)
    print(year, 'verified Excel vs SAS',len(d),'respondents ×',len(cols)+1,'columns')

if __name__=='__main__':
    histories = disability_history()
    for year,wave in [(2018,'07'),(2024,'10')]:
        analyze(year,wave,histories[wave])
    for key in ['adjud','noadjud']:
        for year,n in [(2018,7),(2024,10)]:
            col = f'KLoSA {year} ({n}차)'
            metadata[key][col] = metadata[key][col].replace(f'w{n:02}C003',f'w01C003 ~ w{n:02}C003 (매 차수 동일인 연결)')
    results = pd.DataFrame(records)
    dictionary = pd.DataFrame(metadata.values())
    assert not results.duplicated(['지표ID','연도','구분','집단']).any()
    assert (results['유효 응답 수']+results['결측 수']==results['대상자 수']).all()
    baseline = pd.read_csv(ROOT/'analysis/klosa_common_care_20261012/tables/01_need_summary.csv')
    for key,old,metric in [('adl4','adl4','도움 필요'),('iadl4','iadl4','도움 필요'),('need8','common8','도움 필요'),
                            ('full17','full17','도움 필요'),('nohelper','common8','필요자 중 도움 없음')]:
        ref = baseline[(baseline.definition==old)&(baseline.metric==metric)].iloc[0]
        actual = results[(results.연도==2024)&(results.구분=='전체')&(results.지표ID==key)].iloc[0]
        assert ref.event_n==actual['해당자 수'] and np.isclose(ref.weighted_rate*100,actual['가중 추정값'])
    for year in (2018,2024):
        t=results[(results.연도==year)&(results.구분=='전체')].set_index('지표ID')
        assert np.isclose(t.loc['need8','가중 추정값'], t.loc['adl4','가중 추정값']+t.loc['iadlonly','가중 추정값'])
    unavailable = results['자료 상태'].eq('현 배포본 미제공')
    results.loc[unavailable,['대상자 수','유효 응답 수','결측 수']] = np.nan
    for count_column in ['대상자 수','유효 응답 수','결측 수','해당자 수']:
        results[count_column] = results[count_column].astype('Int64')
    dictionary.to_csv(OUT/'한중_변수대응표.csv',index=False,encoding='utf-8-sig')
    results.to_csv(OUT/'한국_가중결과.csv',index=False,encoding='utf-8-sig',float_format='%.8f')
    print(results[results.구분=='전체'].pivot(index='지표',columns='연도',values='가중 추정값').round(2).to_string())
