import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
const req=createRequire(import.meta.url);
const {Workbook,SpreadsheetFile}=await import(req.resolve('@oai/artifact-tool',{paths:[process.env.NODE_PATH||'.']}));
const here=path.dirname(fileURLToPath(import.meta.url)), root=path.resolve(here,'../..');
const site=path.join(root,'sites/ageing-health-atlas'), dl=path.join(site,'dist/downloads');
const out=path.join(root,'outputs','01a12ed3-13c5-77b1-a223-5b74e3a71bc7');
const D=JSON.parse(await fs.readFile(path.join(site,'tools/subgroups.json'),'utf8'));
const keys=['adl4','multi','mmse','need8'], limits=['n','neither','onset','resolved','both'];
const navy='#204349', ink='#213437', muted='#577477', pale='#EAF3F1';
const previewDir=path.join('/private/tmp','atlas-subgroup-workbook-previews');
await fs.mkdir(previewDir,{recursive:true});await fs.mkdir(out,{recursive:true});
for(const [i,lang] of ['ko','en'].entries()){
 const t=(ko,en)=>[ko,en][i], w=Workbook.create();
 function sheet(name,title,subtitle,widths,rows=65){
  const s=w.worksheets.add(name);s.showGridLines=false;
  const area=s.getRangeByIndexes(0,0,rows,widths.length);area.format.font={name:'Arial',size:10,color:ink};area.format.rowHeight=24;area.format.verticalAlignment='center';
  widths.forEach((v,c)=>s.getRangeByIndexes(0,c,rows,1).format.columnWidthPx=v);
  for(const [r,txt] of [title,subtitle].entries()){
   const g=s.getRangeByIndexes(r,0,1,widths.length);g.merge();g.values=[[txt]];g.format.rowHeight=r?34:39;
   g.format.font={name:'Arial',size:r?10:17,bold:!r,color:r?muted:navy};g.format.wrapText=true;
  }
  return s;
 }
 function table(s,r,head,body){
  const top=s.getRangeByIndexes(r-1,0,1,head.length);top.values=[head];top.format.fill=navy;top.format.font={name:'Arial',size:10,bold:true,color:'#FFFFFF'};top.format.wrapText=true;top.format.rowHeight=44;
  const g=s.getRangeByIndexes(r,0,body.length,head.length);g.values=body;g.format.rowHeight=27;
 }
 function fmt(s,row,col,n,pattern){s.getRangeByIndexes(row-1,col,n,1).setNumberFormat(pattern);}
 for(const year of [2024,2018]){
  const rows=D.headline.filter(r=>r.year===year);
  const s=sheet(String(year),t(year+'년 한국 65세 이상 집단별 건강·돌봄',year+' · Health and care among adults aged 65+ in Korea'),
  (year===2018?t('2018년 인지검사 점수는 현 배포본 미제공. ','2018 cognitive scores are unavailable in this release. '):'')+t('비율·평균은 횡단가중치 적용. n은 각 지표의 비가중 유효 응답 수.','Estimates use cross-sectional weights. Each n counts valid, unweighted responses.'),[150,205,82,142,76,135,76,132,76,146,76]);
  const heads=[t('분류','Stratum'),t('집단','Group'),t('표본 수','Sample N')];
  D.short.forEach(label=>heads.push(label[i]+(label===D.short[2]?t(' (0–30점)',' (0–30)'):''),'n'));
  table(s,4,heads,rows.map(r=>[D.kinds[r.kind][i],D.groups[r.kind+'.'+r.group][i],r.n,...keys.flatMap(k=>[r[k]===null?null:r[k]/(k==='mmse'?1:100),r[k+'_n']])]));
  for(const [c,k] of keys.entries()){fmt(s,5,3+c*2,rows.length,k==='mmse'?'0.0':'0.0%');fmt(s,5,4+c*2,rows.length,'#,##0');}
  fmt(s,5,2,rows.length,'#,##0');s.freezePanes.freezeRows(4);
  rows.forEach((r,j)=>{if(!j||rows[j-1].kind!==r.kind){s.getRangeByIndexes(4+j,0,1,11).format.fill=pale;}});
 }
 const f=sheet(t('동일인 추적','Sample linkage'),t('표본 중복과 동일인 변화','Sample overlap and within-person transitions'),t('인원과 재관측률은 비가중. 두 조사 모두 유효한 사람만 전이표에 포함.','Unweighted counts and retention rates. Transition tables require valid data at both endpoints.'),[285,134,134,134,150,136]);
 table(f,4,[t('분석 표본','Analytic population'),t('인원','People')],Object.entries(D.flow).map(([k,n])=>[D.flow_labels[k][i],n]));
 table(f,17,[t('지표','Indicator'),t('양 시점 유효','Valid at both'),t('두 번 모두 없음','Neither wave'),t('2024년에만 있음','2024 only'),t('2018년에만 있음','2018 only'),t('두 번 모두 있음','Both waves')],D.paired.map(r=>[D.short[keys.indexOf(r.key)][i],...limits.map(k=>r[k])]));
 table(f,24,[t('2018년 소득','2018 income'),t('기준 표본','Baseline N'),t('2024년 재관측','Seen in 2024'),t('재관측률','Retention'),t('사망자조사 기록','Recorded deaths'),t('기타 미관측','Other unobserved')],D.retention.map(([q,n,seen,dead,other])=>['Q'+q,n,seen,null,dead,other]));
 f.getRange('D25:D28').formulas=D.retention.map((_,j)=>['=C'+(25+j)+'/B'+(25+j)]);fmt(f,25,3,4,'0.0%');
 const m=sheet(t('소득 기준과 방법','Income and methods'),t('소득 기준과 지표 해석','Income cutoffs and interpretation'),t('소득 경계는 연간 만원. 2018년은 2017년 소득, 2024년은 2023년 소득.','Cutoffs in KRW 10,000 per year. The 2018 and 2024 waves refer to income in 2017 and 2023 respectively.'),[168,112,114,145,145,145]);
 table(m,4,[t('조사연도','Wave'),t('소득 유효 n','Valid income'),t('소득 미상 n','Missing income'),'P25','P50','P75'],D.cuts.map(c=>[c.year,c.valid,c.missing,...c.cuts]));
 for(let c=3;c<6;c++)fmt(m,5,c,2,'#,##0.00');
 for(const [j,a] of D.methods.entries()){
  const y=8+j*2, label=m.getRangeByIndexes(y,0,1,1), val=m.getRangeByIndexes(y,1,1,5);
  val.merge();val.values=[[a[2+i]]];val.format.wrapText=true;val.format.rowHeight=55;
  label.values=[[a[i]]];label.format.wrapText=true;label.format.font={bold:true,color:navy};
 }
 w.recalculate();
 const inspect=await w.inspect({kind:'table',range:'2024!A4:K7',include:'values,formulas',tableMaxRows:4,tableMaxCols:11});
 if(!inspect.ndjson.includes('2024')&&!inspect.ndjson.includes('16.')){console.log('Inspected',lang,inspect.ndjson.length);}
 for(const s of w.worksheets.items){const image=await w.render({sheetName:s.name,range:s.name==='2024'||s.name==='2018'?'A1:K9':'A1:F11',scale:0.9,format:'png'});await fs.writeFile(path.join(previewDir,lang+'-'+s.name+'.png'),new Uint8Array(await image.arrayBuffer()));}
 const bad=await w.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#NUM!|#SPILL!',options:{useRegex:true,maxResults:3},summary:'errors'});
 if(bad.ndjson.includes('"values":[["#'))throw Error(bad.ndjson);
 const file='subgroups-'+lang+'.xlsx';await (await SpreadsheetFile.exportXlsx(w)).save(path.join(out,file));await fs.copyFile(path.join(out,file),path.join(dl,file));console.log(file);
}
