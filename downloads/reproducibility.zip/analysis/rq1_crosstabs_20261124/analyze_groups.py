"""RQ1 sample linkage and stratified estimates. Writes aggregate data only."""
import io
import json
import re
import sys
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT / 'analysis/rq1_health_ltc_20261123'))
import analyze as rq

PRIMARY = ['adl4', 'multi', 'mmse', 'need8']
ESTIMATES = []
HEADLINES = []
CUTS = []
GROUPS = {}

def group(kind, name, ko, en, mask):
    GROUPS[kind + '.' + name] = [ko, en]
    return kind, name, mask

def summarize(year, data):
    a = data['profile']
    w = a.wgt_ac
    income = a.hhinc.where(a.hhinc.ge(0)) / np.sqrt(a.hhsize.where(a.hhsize.ge(1)))
    valid = income.notna()
    cuts = rq.weighted_quantiles(income[valid].to_numpy(), w[valid].to_numpy())
    quint = pd.Series(np.searchsorted(cuts, income, side='left') + 1, index=a.index).where(valid)
    data['income_q'] = pd.Series(quint.to_numpy(), index=a.pid)
    CUTS.append(dict(year=year, valid=int(valid.sum()), missing=int((~valid).sum()), cuts=cuts.tolist()))
    sexes = [(str(n),ko,en,a.gender1.eq(n)) for n,ko,en in [(1,'남성','Men'),(5,'여성','Women')]]
    ages = [(k,ko,en,a.A002_age.between(lo,hi)) for k,ko,en,lo,hi in [
        ('65','65–74세','65–74',65,74),('75','75–84세','75–84',75,84),('85','85세 이상','85+',85,150)]]
    eds = [(str(i),ko,en,a.edu.eq(i)) for i,(ko,en) in enumerate(zip(
        ['초졸 이하','중졸','고졸','대졸 이상'],['Primary or less','Middle school','High school','College or higher']),1)]
    qs = [(str(i),ko,en,quint.eq(i)) for i,ko,en in [(1,'1분위 (하위)','Q1 (lowest)'),(2,'2분위','Q2'),(3,'3분위','Q3'),(4,'4분위 (상위)','Q4 (highest)')]]
    all_mask = pd.Series(True,index=a.index)
    groups = [group('all','all','전체','All aged 65+',all_mask)]
    for kind, entries in [('sex',sexes),('age',ages),('edu',eds),('income',qs)]:
        if kind != 'income':
            assert sum(int(v.sum()) for _,_,_,v in entries)==len(a)
        groups += [group(kind,k,ko,en,mask) for k,ko,en,mask in entries]
    for kind,left,right in [('sex_age',sexes,ages),('age_income',ages,qs),('sex_income',sexes,qs)]:
        for lk,lko,len_,lm in left:
            for rk,rko,ren,rm in right:
                groups.append(group(kind,lk+'_'+rk,lko+' · '+rko,len_+' · '+ren,lm&rm))
    data['by_pid'] = {k: pd.Series(data['indicators'][k][0].to_numpy(),index=a.pid) for k in PRIMARY}
    for kind, name, mask in groups:
        head = dict(year=year, kind=kind, group=name, n=int(mask.sum()))
        for key,(v,eligible) in data['indicators'].items():
            if '_' in kind and key not in PRIMARY:
                continue
            e = eligible & mask
            m = e & v.notna()
            n = int(m.sum())
            pct = rq.metadata[key]['단위']=='%'
            unavailable = year==2018 and key in rq.scores_2024
            wt = float(w[m].sum())
            num = float((w[m]*v[m]).sum())
            val = num/wt*(100 if pct else 1) if n else None
            events = int(v[m].sum()) if pct and n else None
            status = 'unavailable' if unavailable else 'none' if not n else 'estimated'
            ESTIMATES.append(dict(year=year,kind=kind,group=name,key=key,group_n=head['n'],eligible=int(e.sum()),valid=n,
                missing=None if unavailable else int(e.sum())-n, events=events,weight=wt if n else None,value=val,status=status))
            if key in PRIMARY:
                head[key] = val
                head[key+'_n'] = n if not unavailable else None
        HEADLINES.append(head)

def main():
    histories = rq.disability_history()
    waves = {}
    for year,wave in [(2018,'07'),(2024,'10')]:
        d = waves[year] = {}
        rq.analyze(year,wave,histories[wave],d)
        summarize(year,d)
    d,e = waves.values()
    old,new = [set(x['profile'].pid) for x in (d,e)]
    common,lost,entered = old & new, old-new, new-old
    old_ages = d['all_ages'].reindex(sorted(entered))
    young = int(old_ages.lt(65).sum())
    assert young + int(old_ages.isna().sum())==len(entered)
    deaths=set()
    with zipfile.ZipFile(ROOT/'KLoSA/KLoSA_Exit_2024.zip') as z:
        for wave in [8,9,10]:
            name = next(n for n in z.namelist() if re.fullmatch(f'w{wave:02}_exit.*dta',n))
            deaths.update(pd.read_stata(io.BytesIO(z.read(name)),columns=['pid'],convert_categoricals=False).pid)
    assert not new & deaths
    flow=dict(old=len(old),new=len(new),common=len(common),lost=len(lost),death=len(lost&deaths),
              other=len(lost-deaths),entered=len(entered),younger=young,absent=len(entered)-young,unique=len(old|new))
    paired=[]
    for k in ['adl4','multi','need8']:
        pairs=pd.concat([x['by_pid'][k].reindex(sorted(common)) for x in (d,e)],axis=1).dropna()
        a,b=pairs.iloc[:,0],pairs.iloc[:,1]
        counts=[int(((a==i)&(b==j)).sum()) for i,j in [(0,0),(0,1),(1,0),(1,1)]]
        assert sum(counts)==len(pairs)
        paired.append(dict(key=k,n=len(pairs),neither=counts[0],onset=counts[1],resolved=counts[2],both=counts[3]))
    retention=[]
    for q in range(1,5):
        ids=set(d['income_q'].index[d['income_q'].eq(q)])
        retention.append([q,len(ids),len(ids&common),len(ids&deaths),len(ids-lost.intersection(deaths)-common)])
    # Reconcile every all-ages estimate with the published analysis as a separate control.
    ref=pd.read_csv(ROOT/'analysis/rq1_health_ltc_20261123/한국_가중결과.csv')
    ref=ref.loc[ref['구분']=='전체'].set_index(['연도','지표ID'])
    for r in ESTIMATES:
        if r['kind']=='all':
            x=ref.loc[r['year'],r['key']]
            assert (pd.isna(x['유효 응답 수']) if r['status']=='unavailable' else x['유효 응답 수']==r['valid']) and np.isclose(x['가중 추정값'], np.nan if r['value'] is None else r['value'],equal_nan=True)
    for year in waves:
        for k in PRIMARY:
            these=[r for r in ESTIMATES if r['year']==year and r['key']==k]
            total=next(r for r in these if r['kind']=='all')
            for kind in ['sex','age','edu','sex_age']:
                rows=[r for r in these if r['kind']==kind]
                assert sum(r['valid'] for r in rows)==total['valid']
                assert np.isclose(sum(r['weight'] or 0 for r in rows),total['weight'] or 0)
            for kind in ['age_income','sex_income']:
                assert sum(r['valid'] for r in these if r['kind']==kind)==sum(r['valid'] for r in these if r['kind']=='income')
    result=dict(groups=GROUPS,headline=HEADLINES,detail=ESTIMATES,cuts=CUTS,flow=flow,paired=paired,retention=retention)
    (OUT/'aggregates.json').write_text(json.dumps(result,ensure_ascii=False,allow_nan=False))
    print(flow,paired,retention,CUTS,flush=True)

if __name__=='__main__':
    main()
