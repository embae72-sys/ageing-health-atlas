"""Format the reviewed aggregate data in Korean and English."""
import csv
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
SITE=ROOT/'sites/ageing-health-atlas'
DOWNLOAD=SITE/'dist/downloads'
KINDS={
'all':('전체','Overall'),'sex':('성별','Sex'),'age':('연령','Age'),'edu':('학력','Education'),
'income':('가구소득','Household income'),'sex_age':('성별 × 연령','Sex × age'),
'age_income':('연령 × 소득','Age × income'),'sex_income':('성별 × 소득','Sex × income')}
MAINS=['adl4','multi','mmse','need8']
SHORT=[('기본 4항목 도움 필요','Help with ≥1 basic activity (of 4)'),('복합만성질환','≥2 of 8 diagnoses'),('K-MMSE-2 평균','Mean K-MMSE-2'),('공통 8항목 도움 필요','Help with ≥1 activity (of 8)')]
FLOW={
'old':('2018년 65세 이상','Aged 65+ in 2018'),'new':('2024년 65세 이상','Aged 65+ in 2024'),
'common':('두 조사 모두 65세 이상으로 응답','Interviewed at age 65+ in both waves'),'lost':('2018년만 65세 이상으로 응답','In 2018 eligible sample only'),
'death':('  이 중 8–10차 사망자조사에서 확인','  With a death recorded in waves 8–10'),'other':('  이 중 그 밖의 2024년 미관측','  Other unobserved in 2024'),
'entered':('2024년에만 65세 이상으로 응답','In 2024 eligible sample only'),'younger':('  이 중 2018년 65세 미만 응답','  Interviewed below age 65 in 2018'),
'absent':('  이 중 2018년 기본조사 미응답','  No 2018 main interview'),'unique':('한 번 이상 포함된 고유 인원','Distinct people across both waves')}
METHODS=[
('2018년과 2024년의 분모','Study populations','각 연도 면접 당시 65세 이상. 2024년은 최근 한국 단면, 2018년은 CHARLS 4차와 같은 해의 비교 기준이다. 중국 응답자료는 확보 전이다.','Age 65+ at each interview. Use 2024 for the recent Korean profile and 2018 as the reference for CHARLS wave 4. Chinese respondent data are pending.'),
('횡단 가중치와 표본 수','Weights and counts','비율과 평균은 각 연도 개인 통합 횡단가중치(wgt_ac)를 적용했다. 인원은 비가중 실측 수이며, 지표별 유효 인원이 분모다.','Estimates use each wave’s integrated individual cross-sectional weight (wgt_ac). Counts are unweighted. Each estimate uses valid responses to that indicator.'),
('소득 4분위','Income quartiles','조사 전년도 가구소득(부동산·금융소득 제외, 만원/년)을 조사 시 가구원 수의 제곱근으로 나눴다. 각 연도 65세 이상에서 별도로 가중 4분위를 정하고 경계값은 낮은 분위에 넣었다.','Prior-year household income excludes real-estate and financial income. Divide by the square root of household size at interview. Compute weighted quartiles separately among eligible respondents with known income in each wave. Ties at a cutoff enter the lower quartile.'),
('소득 결측','Missing income','소득 미상은 소득을 사용하는 표에서만 제외한다. 전체·성·연령·학력 표에는 포함한다. 소득 기준표의 금액 단위는 연간 만원이다.','Exclude missing income only in income-based tables. The overall, sex, age and education tables retain these respondents. Income cutoffs are in KRW 10,000 per year.'),
('지표 읽기','Reading indicators','기본 4항목은 옷 입기·목욕·식사·화장실 이용, 공통 8항목은 여기에 식사 준비·약 복용·물건 사기·금전 관리를 더했다. 하나 이상에서 부분 또는 전적 도움이 필요하면 해당한다.','The four basic activities are dressing, bathing, eating and toileting. The eight common activities also include preparing meals, taking medication, shopping and managing money. Any partial or full assistance meets the threshold.'),
('만성질환과 인지','Conditions and cognition','복합만성질환은 지정한 8개 신체질환 중 2개 이상의 의사 진단 경험이다. K-MMSE-2는 0–30점으로 2024년 유효 응답의 평균을 제시한다. 2018년 현 배포본에는 점수가 없다.','Multimorbidity means at least two of eight physician-diagnosed physical conditions. K-MMSE-2 is a 0–30 score. We report the 2024 mean among valid tests. The 2018 scores are unavailable in this release.'),
('추적 분석','Linked respondents','양 시점에서 모두 65세 이상으로 응답하고 해당 지표도 모두 유효한 사람만 포함한다. 전이 인원과 비율은 비가중이며 두 시점 사이에 일어난 중간 변화는 관측하지 않는다.','Paired transitions use respondents aged 65+ and valid for the indicator at both endpoints. Counts and percentages are unweighted. Intermediate changes are unobserved.'),
('집단 간 차이','Group differences','연령·성별 등을 보정하지 않은 기술통계다. 같은 연령대 안에도 잔여 연령차가 있을 수 있다. 두 연도의 응답자가 겹치므로 독립표본으로 다루지 않는다.','Descriptive estimates are unadjusted. Residual differences in age may persist within age bands. The samples overlap and should not be treated as independent.'),
('한국 원자료','KLoSA microdata','https://survey.keis.or.kr/klosa/klosadownload/List.jsp','https://survey.keis.or.kr/klosa/klosadownload/List.jsp'),
('중국 비교 기준','CHARLS wave 4','https://charls.pku.edu.cn/en/Data/a2018_CHARLS_Wave_4.htm','https://charls.pku.edu.cn/en/Data/a2018_CHARLS_Wave_4.htm')]
def main():
    (SITE/'tools').mkdir(parents=True,exist_ok=True)
    src=json.loads((HERE/'aggregates.json').read_text())
    compact={k:src[k] for k in src if k!='detail'}
    compact.update(kinds=KINDS,short=SHORT,flow_labels=FLOW,methods=METHODS)
    (SITE/'tools/subgroups.json').write_text(json.dumps(compact,ensure_ascii=False))
    for i,lang in enumerate(['ko','en']):
        t=lambda ko,en:(ko,en)[i]
        with (DOWNLOAD/f'crosswalk-{lang}.csv').open(encoding='utf-8-sig') as f:
            entries={r[0]:r[1:5] for r in list(csv.reader(f))[1:]}
        heads=t(['연도','분류','집단','지표 ID','영역','지표','단위','분모 정의','집단 인원','대상자 수','유효 인원','결측 인원','해당 인원','가중 유효 분모','가중 추정값','자료 상태'],
                ['Year','Stratification','Group','Indicator ID','Domain','Indicator','Unit','Denominator definition','Group N','Eligible N','Valid N','Missing N','Event N','Weighted valid denominator','Weighted estimate','Status'])
        rows=[]
        for r in src['detail']:
            area,name,unit,base=entries[r['key']]
            na=r['status']=='unavailable'
            lab={'estimated':t('산출','Estimated'),'unavailable':t('현 배포본 미제공','Unavailable in this release'),'none':t('유효 응답 없음','No valid responses')}[r['status']]
            rows.append([r['year'],KINDS[r['kind']][i],src['groups'][r['kind']+'.'+r['group']][i],r['key'],area,name,unit,base,r['group_n'],None if na else r['eligible'],None if na else r['valid'],r['missing'],r['events'],r['weight'],r['value'],lab])
        with (DOWNLOAD/f'subgroups-{lang}.csv').open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.writer(f);w.writerow(heads);w.writerows(rows)
if __name__=='__main__':
    main()
